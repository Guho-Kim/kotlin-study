package edu.skku.map.week6

class ChatRoom(
    val name: String,
    val lastChat: String,
    val thumbnail: Int,
    val groupNumber: Int,
    val lastTime: String,
    val unreadCount: Int,
) {

}